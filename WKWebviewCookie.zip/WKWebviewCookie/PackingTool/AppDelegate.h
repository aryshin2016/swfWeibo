//
//  AppDelegate.h
//  SQPackingTool
//
//  Created by if you on 2017/5/4.
//  Copyright © 2017年 if you. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

