#import "GPUImageFilter.h"

@interface LFGPUImageEmptyFilter : GPUImageFilter
{
}

@end
