#import "GPUImageFilter.h"

@interface LFGPUImageBeautyFilter : GPUImageFilter {
}

@property (nonatomic, assign) NSInteger beautyLevel;

@end
