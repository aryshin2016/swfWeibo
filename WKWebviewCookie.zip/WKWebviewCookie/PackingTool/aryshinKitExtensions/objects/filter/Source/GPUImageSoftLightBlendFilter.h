#import "GPUImageTwoInputFilter.h"

@interface GPUImageSoftLightBlendFilter : GPUImageTwoInputFilter
{
}

@end
