#import "GPUImageFilter.h"

@interface GPUImageHistogramGenerator : GPUImageFilter
{
    GLint backgroundColorUniform;
}

@end
