//
//  UIButton+Image.h
//  WeiBoSwift
//
//  Created by itogame on 2017/8/16.
//  Copyright © 2017年 itogame. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (Image)

+ (instancetype)buttonWithText:(NSString *)text;

@end
